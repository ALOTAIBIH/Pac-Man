# myTeam.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from captureAgents import CaptureAgent
import random, time, util
from game import Directions
import game
from game import Actions
from game import Directions
# import numpy as np
import math as m
from util import nearestPoint

#################
# Team creation #
#################

def createTeam(firstIndex, secondIndex, isRed,
               first = 'ProtectingAgent', second = 'AttackingAgent'):
  """
  This function should return a list of two agents that will form the
  team, initialized using firstIndex and secondIndex as their agent
  index numbers.  isRed is True if the red team is being created, and
  will be False if the blue team is being created.

  As a potentially helpful development aid, this function can take
  additional string-valued keyword arguments ("first" and "second" are
  such arguments in the case of this function), which will come from
  the --redOpts and --blueOpts command-line arguments to capture.py.
  For the nightly contest, however, your team will be created without
  any extra arguments, so you should make sure that the default
  behavior is what you want for the nightly contest.
  """

  # The following line is an example only; feel free to change it.
  return [eval(first)(firstIndex), eval(second)(secondIndex)]

##########
# Agents #
##########

class ReflexCaptureAgent(CaptureAgent):
      
  recent_moves = []
  possible_directions = [Directions.NORTH, Directions.SOUTH, Directions.EAST, Directions.WEST]
      
  def registerInitialState(self, gameState):
    self.start = gameState.getAgentPosition(self.index)
    CaptureAgent.registerInitialState(self, gameState)
    self.possible_directions = set(self.possible_directions)

  def isGoalState(self, myPos, goal_pos):
    # myPos = state.getAgentPosition(self.index)
    return myPos == goal_pos

  def heuristic(self, mypos, startpos):
    # mypos = curState.getAgentPosition(self.index)
    # startpos = startState.getAgentPosition(self.index)
    return self.getMazeDistance(mypos, startpos)

    return 0

  def aStarSearch(self, gameState, myPos, goal_pos):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    myPQ = util.PriorityQueue()
    startPos = myPos
    startNode = (startPos, '',0, [])
    myPQ.push(startNode,self.heuristic(startPos,startPos))
    visited = set()
    best_g = dict()
    while not myPQ.isEmpty():
      node = myPQ.pop()
      curPos, action, cost, path = node
      if (not curPos in visited) or cost < best_g.get(curPos):
        visited.add(curPos)
        best_g[curPos]=cost
        if self.isGoalState(curPos, goal_pos):
          path = path + [(curPos, action)]
          actions = [action[1] for action in path]
          del actions[0]
          return actions
        all_actions = self.possible_directions
        # = state.getLegalActions(self.index)

        for succAction in all_actions:
          # print(action)
          # print(path)
          succ_x, succ_y = Actions.getSuccessor(curPos, succAction)
          succPos = (int(succ_x), int(succ_y))
          # print(succPos)
          if gameState.hasWall(int(succ_x), int(succ_y)): continue
          # succState = curPos.generateSuccessor(self.index, succAction)
          newNode = (succPos, succAction, cost + 1, path + [(node, action)])
          myPQ.push(newNode,self.heuristic(succPos,startPos)+cost+1)

  def findCenterPos(self, gameState):
    total_width = gameState.data.layout.width
    total_height = gameState.data.layout.height
    offset = 1
    if gameState.isOnRedTeam(self.index):
      offset = -1
    # print('finding center pos')
    
    if not self.home_x:
      self.home_x = m.floor(total_width / 2) - 1

    for y in range(total_height):
      if not gameState.hasWall(self.home_x + offset, y) :
        self.escape_pos.append((self.home_x + offset, y))
      # if not gameState.hasWall(self.home_x, y) :
      #   self.attack_pos.append((self.home_x, y))

    # minDistance = float('inf')
    # for position in self.escape_pos:
    #   if self.getMazeDistance(self.start_pos, position) < minDistance:
    #     minDistance = self.getMazeDistance(self.start_pos, position)
    #     self.attackPos = position

    return

  def evaluate(self, state, action):
    
    features = self.getFeatures(state, action)
    weights = self.getWeights(state, action)
    # print(features * weights)
    return features * weights
  
  def isStuck(self):
    if len(self.recent_moves) > 4:
      self.recent_moves = self.recent_moves[-4:]
    if len(self.recent_moves) < 4:
      return False

    if ((len(set(self.recent_moves)) == len(self.possible_directions)) or 
        (self.recent_moves[0] != self.recent_moves[1] and 
        self.recent_moves[0] == self.recent_moves[2] and self.recent_moves[1] == self.recent_moves[3])):
      self.stuck_counter += 1
      if (self.stuck_counter > 3):
        return True
    else:
      self.stuck_counter = 0
    return False


class AttackingAgent(ReflexCaptureAgent):

  max_distance = None
  home_x = None
  capsules = []
  food = None
  start_pos = None
  aStarPath = []
  pathToAttackPos = []
  attack_path_counter = 0
  attack_pos = None
  deepest_trapped_food = None
  escape_pos = []
  total_food_count = None
  food_count = None
  defend = False
  is_going_home = False
  is_center_adjusted = False
  stuck_counter = 0
  # recent_moves = []
  trapped_food = util.PriorityQueue()
  inactivity = 0
  atHome_count = 0
  trap_list = []
  trap_depths = util.Counter()
  trapped_food_paths = util.Counter()
  max_trap_depth = 0
  max_eval_value = 99999
  entry_point = None
  max_distance = 40
  detour_no_entry = None

  def getUntrappedFood(self, gameState, food_list) :
    not_trapped_list = []
    for food in food_list:
      legalNeighbours = Actions.getLegalNeighbors(food, gameState.getWalls())
      legalNeighbours.remove(food)
      if (len(legalNeighbours) > 2) :
        not_trapped_list.append(food)
    return not_trapped_list;

  def setDeepTrappedFood(self, gameState):
    neighboursQ = []
    self.trapped_food = util.PriorityQueue()
    for food in self.food:
      legalNeighbours = Actions.getLegalNeighbors(food, gameState.getWalls())
      legalNeighbours.remove(food)
      if len(legalNeighbours) > 1:
        continue
      neighboursQ = []
      visitedQ = [food]
      if food not in self.trap_list:
        self.trap_list.append(food)
        self.trap_depths[food] = 0
      for nei in legalNeighbours:
        neighboursQ.append(nei)
        steps = 0
      while len(neighboursQ) > 0:
        next_nei = neighboursQ.pop(0)
        visitedQ.append(next_nei)
        if(next_nei in legalNeighbours):
          steps = 0
        steps += 1
        neighbours = Actions.getLegalNeighbors(next_nei, gameState.getWalls())
        neighbours.remove(next_nei)

        if len(neighbours) > 2:
          self.trapped_food.push(food, (steps * -1))
          for capsule in self.capsules:
            # if steps > 3:
            self.trapped_food_paths[capsule+food] = self.aStarSearch(gameState, capsule, food)
          if steps > self.max_trap_depth:
            self.max_trap_depth = steps
          continue

        if next_nei not in self.trap_list:
          self.trap_list.append(next_nei)
          self.trap_depths[next_nei] = steps

        for nei in neighbours:
          if nei not in visitedQ and nei not in neighboursQ:
            neighboursQ.append(nei)

  def registerInitialState(self, gameState):
    self.start_pos = gameState.getAgentPosition(self.index)
    CaptureAgent.registerInitialState(self, gameState)
    self.capsules = self.getCapsules(gameState)
    self.food = self.getFood(gameState).asList()
    self.findCenterPos(gameState)
    self.attack_pos = self.escape_pos
    # print('escape points')
    # print(self.escape_pos)
    for pos in self.escape_pos:
      self.pathToAttackPos.append(self.aStarSearch(gameState, self.start_pos, pos))
      self.attack_path_counter += 1
      # print(self.pathToAttackPos[-1])
    # print('found '+str(len(self.pathToAttackPos))+' paths')
    self.setDeepTrappedFood(gameState)
    self.food_count = len(self.food)
    # self.total_food_count = len(self.food)
    # self.detour_no_entry = Directions.WEST
    # if gameState.isOnRedTeam(self.index):
    #   self.detour_no_entry = Directions.EAST
    # print('my index')
    # print(self.index)
    # print("I'm starting at : "+str(self.start_pos))
    # print('here is my trap list')
    # print(self.trap_list)
    # print(self.max_trap_depth)

  def findInRangeGhost(self, state, myPos) :
    inRange = []
    closestDist = float('inf')
    enemy_indices = self.getOpponents(state)
    for index in enemy_indices:
      enemy_agent = state.getAgentState(index)
      enemy_pos = enemy_agent.getPosition()
      #  and self.getMazeDistance(myPos, enemy_pos) < 7
      if (enemy_pos and self.getMazeDistance(myPos, enemy_pos) < 10 and 
          ((not self.defend and self.getMazeDistance(myPos, enemy_pos) < 7 and 
          enemy_agent.scaredTimer < 7 and not enemy_agent.isPacman) or
          (self.defend and enemy_agent.isPacman))):
        inRange.append(enemy_agent)
        if self.getMazeDistance(myPos, enemy_pos) < closestDist:
          closestDist = self.getMazeDistance(myPos, enemy_pos) 
    return inRange, closestDist

  def getFeatures(self, state, action):
    features = util.Counter()
    pos = state.getAgentState(self.index).getPosition()
    successor = state.generateSuccessor(self.index, action)
    myPos = successor.getAgentState(self.index).getPosition()

    # Compute score from successor state
    features['successorScore'] = self.getScore(successor)    
    # Compute if is pacman
    features['isPacman'] = 1 if successor.getAgentState(self.index).isPacman else 0

    inRange, closestDist = self.findInRangeGhost(successor, myPos)
    # print("ghost list when in features")
    # print(len(inRange))

    if self.defend:
      if successor.getAgentState(self.index).isPacman:
        # print("I want to defend")
        self.is_going_home = True
        self.defend = False
        inRange, closestDist = self.findInRangeGhost(successor, myPos)
      else:
        features['isPacman'] = 0 if successor.getAgentState(self.index).isPacman else 1
        if (len(inRange) > 0):
          features['distanceToPacman'] = closestDist

    if self.entry_point:
          
      # print("I see ghost")
      # print("decided entry point is "+str(self.entry_point))
      features['isPacman'] = 0 if successor.getAgentState(self.index).isPacman else 1
      my_x, my_y = myPos
      entry_x, entry_y = self.entry_point
      entry_col = (my_x, entry_y)
      features['distanceToEntry'] = abs(my_y - entry_y)
      if features['distanceToEntry'] < 5:
        self.detour_no_entry = None
      if not self.detour_no_entry:
        features['distanceToEntry'] = self.getMazeDistance(myPos, self.entry_point)
      # util.manhattanDistance(myPos, self.entry_point)
      # features['distanceToGhost'] = self.max_distance
      # if len(inRange) > 0:
      #   features['distanceToGhost'] = closestDist
      self.getMazeDistance(myPos, self.entry_point)
      # sdf = self.get
      # print('---------------')
      # print(myPos)
      # print(features)
      # print('---------------')
      return features

    features['distanceToGhost'] = self.max_distance

    # if (self.inactivity > 46 and closestDist > 7):
    #   self.inactivity = 0
    #   self.defend = False
    #   inRange, closestDist = self.findInRangeGhost(successor, myPos)

    # Compute distance to the nearest food
    foodList = self.getFood(successor).asList()

    features['location_trapped'] = -1
    features['trap_depth'] = self.max_trap_depth + 2

    if (len(inRange) > 0 and not self.defend):
          
      # print("I see ghost")
      # print("decided entry point is "+str(self.entry_point))
          
      features['distanceToGhost'] = closestDist

      # legal_actions = successor.get
      legal_actions = state.getLegalActions(self.index)
      legal_actions.remove(Directions.STOP)

      reversed_direction = Directions.REVERSE[state.getAgentState(self.index).configuration.direction]
      if reversed_direction in legal_actions:
        legal_actions.remove(reversed_direction)

      # self.checkForTrap(legal_actions, state, 0)
      features['location_trapped'] = -1
      features['trap_depth'] = self.max_trap_depth + 2
      if myPos in self.trap_list:
        features['location_trapped'] = 1
        features['trap_depth'] = self.trap_depths[myPos]
      
      
      """ legalNeighbours = Actions.getLegalNeighbors(myPos, successor.getWalls())
      legalNeighbours.remove(myPos)
      features['location_trapped'] = -1
      if len(legalNeighbours) < 3:
        features['location_trapped'] = 1 """
      
      if (successor.getAgentState(self.index).isPacman) :
        foodList = self.getUntrappedFood(successor, foodList)
        if (len(foodList) == 0 and 
          successor.getAgentState(self.index).numCarrying == 0):
          foodList = self.getFood(successor).asList()

      if len(self.capsules) > 0:
        # print('********************************************')
        # print(len(self.capsules))
        
        minDistance = 0
        if (myPos not in self.capsules):
          minDistance = min([self.getMazeDistance(myPos, food) for food in self.capsules])
        features['distanceToCapsule'] = minDistance

      # if self.entry_point:
      #   features['distanceToEntry'] = self.getMazeDistance(myPos, self.entry_point)

    if (len(foodList) > 0 and not self.defend):
      minDistance = 0
      if (myPos not in self.food):
        minDistance = min([self.getMazeDistance(myPos, food) for food in foodList])
      features['distanceToFood'] = minDistance



    if self.is_going_home:
      minDistance = min([self.getMazeDistance(myPos, pos) for pos in self.escape_pos])
      # if minDistance > features['distanceToGhost']:
      #   self.is_going_home = False
      # else :
      features['distanceToHome'] = minDistance
      features['isPacman'] = 0 if successor.getAgentState(self.index).isPacman else 1

    # print('---------------')
    # print(myPos)
    # print(features)
    # print('---------------')

    return features

  def getWeights(self, state, action):
    """
    Get weights for the features used in the evaluation.
    """
    weights = util.Counter()

    successor = state.generateSuccessor(self.index, action)
    myPos = successor.getAgentState(self.index).getPosition()

    weights['isPacman'] = 2
    weights['location_trapped'] = -5
    weights['trap_depth'] = 5
    weights['distanceToGhost'] = 8

    if self.entry_point:
      weights['distanceToEntry'] = -10
      weights['isPacman'] = 15

    if not self.defend:
      weights['successorScore'] = 2
      weights['distanceToFood'] = -5

      inRange, closestDist = self.findInRangeGhost(successor, myPos)
      if len(inRange) > 0:
        weights['distanceToFood'] = -1
        # weights['distanceToGhost'] = 8
        weights['distanceToCapsule'] = -6
        # weights['distanceToCapsule'] = -7
        weights['location_trapped'] = -5
        weights['trap_depth'] = 5

      if self.is_going_home:
        weights['distanceToHome'] = -2
        weights['distanceToFood'] = -1
    else :
      weights['distanceToPacman'] = -5

    # print('---------------')
    # print(myPos)
    # print(weights)
    # print('---------------')

    return weights

  def simulate(self, state, depth, path, parent_value, isGhostInRange):
    # special_node = (18, 9)
    mypos = state.getAgentPosition(self.index)
    path.append(mypos)
    search_list = self.getFood(state)
    ghost_list = []
    # enemy_indices = self.getOpponents(state)
    inRange, closestDist = self.findInRangeGhost(state, mypos)
    if (len(inRange)):
      ghost_list = [enemy_agent.getPosition() for enemy_agent in inRange]
      search_list = ghost_list
      # found_ghosts_at = mypos

    self_eval = self.evaluate(state, Directions.STOP)
    # print("ghosts in range when in simulation at "+str(mypos))
    # print(len(inRange))
    # print(isGhostInRange)
    if isGhostInRange and len(inRange) == 0:
      if mypos in self.capsules:
        return (self.max_eval_value, 1)
      if parent_value:
        # print("parent saw ghost but I dont")
        return parent_value, 1
    #   print("I don't see ghost from my spot")
    #   print("my parent's value is "+str(parent_value))
    #   if not parent_value:
    #     return self_eval, 1
    #   return parent_value, 1
    # el
    if len(inRange) > 0:
      isGhostInRange = True

    # if len(ghost_list) > 0 and mypos in search_list:
    #   print("I am in ghost list, should return value: "+str(self_eval))
  
    # print ("parent's value "+str(parent_value)+" my value "+str(self_eval))
    # print(mypos in search_list or depth == 0 or (parent_value!=None and self_eval < parent_value))
    if(mypos in search_list or depth == 0 
      or (parent_value!=None and self_eval < parent_value)):
      return (self_eval, 1)

    legal_actions = state.getLegalActions(self.index)
    legal_actions.remove(Directions.STOP)

    reversed_direction = Directions.REVERSE[state.getAgentState(self.index).configuration.direction]
    if reversed_direction in legal_actions and len(legal_actions) > 1:
      legal_actions.remove(reversed_direction)

    value = 0
    n = 1
    val = []
    to_rem = []
    # print("for loop")
    for action in legal_actions:
      state_prime = state.generateSuccessor(self.index, action)
      pos_prime = state_prime.getAgentPosition(self.index)
      # print('from '+str(mypos)+" go to "+str(action)+" when ghosts are:")
      # print(ghost_list)
      # print(pos_prime in self.capsules)
      # print(len(legal_actions))
      # print(isGhostInRange)
      if pos_prime in self.capsules and isGhostInRange:
        v = self.max_eval_value
        continue
      # special = (18, 8)
      if(pos_prime in path or pos_prime == self.start_pos):
        to_rem.append(action)
        continue
      v, new_n = self.simulate(state_prime, depth - 1, path, self_eval, isGhostInRange)
      # if pos_prime in ghost_list and new_n == 1:
      #   print(pos_prime + " is in ghost list, please let me go somewhere else")
      #   return -9999, 1
      # value += v
      val.append(v)
      if (new_n + 1) > n: n = new_n + 1

    for rem_action in to_rem:
      legal_actions.remove(rem_action)

    # print("------------------------------------------------")
    # print('state '+str(mypos))
    # print(legal_actions)
    # print(val)
    # print("n = "+str(n))
    # print("-------------------------------------------------")

    if(len(val) == 0):
      return (self_eval, n - 1)

    return (max(val), n)

  def findNewEntryPoint(self, gameState, myPos):
    # print ("I am at myPos "+str(myPos))
    my_x, my_y = myPos
    maxDist = 0
    # minDistance = min([self.getMazeDistance(myPos, pos) for pos in self.escape_pos])
    for pos in self.escape_pos:
      dist = self.getMazeDistance(myPos,pos)
      if dist > maxDist:
        maxDist = dist
        self.entry_point = pos
  
    self.detour_no_entry = Directions.WEST
    if gameState.isOnRedTeam(self.index):
      self.detour_no_entry = Directions.EAST

  def findDistanceToHome(self, myPos):
    minDistance = 9999
    for position in self.escape_pos:
      if self.getMazeDistance(myPos, position) < minDistance:
        minDistance = self.getMazeDistance(self.start_pos, position)

    return minDistance

  # def getDetourAction(self, state, agentLocation, all_actions):
  #   evaluation = util.Counter()
  #   for action in all_actions:
  #     successor = state.generateSuccessor(self.index, action)
  #     next_pos = successor.getAgentState(self.index).getPosition()
  #     next_x, next_y = next_pos
  #     entry_x, entry_y = self.entry_point
  #     # entry_col = (my_x, entry_y)
  #     evaluation[action] = abs(next_y - entry_y)

      
  #     if len(evaluation.keys()) == 0: return None
  #     all = list(self.items())
  #     values = [x[1] for x in all]
  #     maxIndex = values.index(max(values))
  #     return all[maxIndex][0]
    

  def chooseAction(self, gameState):
    # return None
    agent = gameState.getAgentState(self.index)
    agentLocation = gameState.getAgentPosition(self.index)

    carrying = agent.numCarrying

    # pacman is starting from the start position
    if agentLocation == self.start_pos:
      # self.setDeepTrappedFood(gameState, False)
      path_index = random.randint(0, self.attack_path_counter - 1)
      self.aStarPath = self.pathToAttackPos[path_index]
      # if self.is_center_adjusted:
      self.aStarPath = self.aStarPath[:-2]
      # if len(self.pathToAttackPos) == 0:
      #   # game is starting
      #   self.aStarPath = self.aStarSearch(gameState, self.attackPos)
      #   self.pathToAttackPos = self.aStarPath
      # else :
      #   # pacman died
      #   self.aStarPath = self.pathToAttackPos

    # after pacman eats the deepest trapped food of the moment
    if agentLocation == self.deepest_trapped_food:
      self.deepest_trapped_food = None
      # if (agent.numCarrying > (self.food_count * (1 / 3))):
      #   self.is_going_home = True
        # print("I'm going home")

    self.food = self.getFood(gameState).asList()

    if (agent.numCarrying > (self.food_count * (1 / 3)) or
        agent.numCarrying > 0 and gameState.data.timeleft < 40):
      self.is_going_home = True
      # print("I'm going home")

    if agentLocation in self.escape_pos:
      self.is_going_home = False
      self.food_count = len(self.food)
      self.inactivity = 0


    if (agentLocation in self.capsules) :
      self.capsules.remove(agentLocation)
      # print(" i had capsule now I will have food ")
      while (not self.trapped_food.isEmpty() and not self.deepest_trapped_food):
        self.deepest_trapped_food = self.trapped_food.pop()
        self.aStarPath = self.trapped_food_paths[agentLocation+self.deepest_trapped_food]
        if self.deepest_trapped_food not in self.food or self.aStarPath == 0:
          self.deepest_trapped_food = None
          self.aStarPath = []
      # print("my path ")
      # print(self.aStarPath)
      
      # if self.deepest_trapped_food:
      #   self.aStarPath = self.trapped_food_paths[agentLocation+self.deepest_trapped_food]
        # self.aStarSearch(gameState, agentLocation, self.deepest_trapped_food)

    if len(self.aStarPath) > 0:
      self.inactivity = 0
      aStarAction = self.aStarPath.pop(0)
      self.recent_moves.append(aStarAction)
      # if (not self.is_center_adjusted and not agent.isPacman):
      #     print("I am ghost and ")
      #     new_state = gameState.generateSuccessor(self.index, aStarAction)
      #     if (new_state.getAgentState(self.index).isPacman):
      #       new_pos = new_state.getAgentPosition(self.index)
      #       print("next position "+str(new_pos)+" is pacman")
      #       # self.debugDraw([gameState.getAgentPosition(self.index),new_state.getAgentPosition(self.index)],[1,0,0])
      #       self.home_x, _ = agentLocation
      #       self.home_x += (self.home_x - new_pos[0])
            
      #       self.findCenterPos(gameState)
      #       self.is_center_adjusted = True
      #       aStarAction = None
      # print("return action "+str(aStarAction))
      # if aStarAction:
            # print("I found home at "+str(self.home_x))
        # print("returning "+str(aStarAction))
      return aStarAction
    
    # print("agent location: "+str(agentLocation))

    if agent.isPacman:
      self.atHome_count = 0
      self.entry_point = None
    elif not self.entry_point:
      self.atHome_count += 1

    if self.atHome_count > 20:
      self.atHome_count = 0
      self.findNewEntryPoint(gameState, agentLocation)
      self.debugDraw([agentLocation],[1,0,0])
    
    if (self.inactivity > 80):
      self.is_going_home = True

    # if (self.getScore(gameState) > 5 and (len(self.food) < (self.total_food_count / 2))):
    #   self.defend = True

    # if (self.inactivity > 28):
    #   self.defend = True

    if agentLocation == self.entry_point:
      self.entry_point = None

    all_actions = gameState.getLegalActions(self.index)
    all_actions.remove(Directions.STOP)

    if self.detour_no_entry:
      if self.detour_no_entry in all_actions and len(all_actions) > 1:
        all_actions.remove(self.detour_no_entry)
      # return self.getDetourAction(agentLocation, all_actions)

    evaluations = util.Counter()

    isGhostInRange = False
    inRange, closestDist = self.findInRangeGhost(gameState, agentLocation)
    if len(inRange) > 0:
      isGhostInRange = True
      dis = self.findDistanceToHome(agentLocation)
      # print("distance to home is "+str(dis))
      if dis < 5 and closestDist < 7 and agent.numCarrying > 0:
        self.is_going_home = True
    
    reversed_direction = Directions.REVERSE[gameState.getAgentState(self.index).configuration.direction]
    if reversed_direction in all_actions and len(all_actions) > 1 and len(inRange) == 0:
      # print('remove reverse '+str(reversed_direction))
      all_actions.remove(reversed_direction)
    elif len(all_actions) == 1 and agentLocation not in self.trap_list:
      self.trap_list.append(agentLocation)
      self.trap_depths[agentLocation] = 0
      # print('traplist updated, new addition : '+str(agentLocation) + ' with depth : 0')

    to_rem = []
    neighbour_trap_depths = []
    for action in all_actions:
      path = [agentLocation]
      new_state = gameState.generateSuccessor(self.index, action)
      new_pos = new_state.getAgentPosition(self.index)
      # print("new pos "+str(new_pos)+" capsules "+str(self.capsules))
      # print(new_pos in self.capsules)
      # print(len(all_actions))
      # print(len(inRange))
      if new_pos in self.capsules and len(all_actions) == 2 and len(inRange) > 0:
        return action
      if new_pos in self.trap_list:
        neighbour_trap_depths.append(self.trap_depths[new_pos])
      if new_pos == self.start_pos:
        to_rem.append(action)
        continue
      # print("agent go to "+str(action)+" to "+str(new_pos))
      value, n = self.simulate(new_state, 3, path, None, isGhostInRange)
      evaluations[action] = value #/n

    if (agentLocation not in self.trap_list and 
        ((len(inRange) > 0 and len(neighbour_trap_depths) > 0 and 
        len(neighbour_trap_depths) == len(all_actions) - 1) or
        (len(neighbour_trap_depths) == len(all_actions)))):
      self.trap_list.append(agentLocation)
      self.trap_depths[agentLocation] = max(neighbour_trap_depths) + 1
      # print('traplist updated, new addition : '+str(agentLocation) + ' with depth : '+str(self.trap_depths[agentLocation]))
        

    # print('---------------------')
    # print(evaluations)
    # print(all_actions)
    # print('---------------------')

    for action in to_rem:
      all_actions.remove(action)

    if len(all_actions) == 0 :
      best_action = Directions.STOP
    else :
      best_action = evaluations.argMax()

    # print('---------------------')
    # print(evaluations)
    # print(all_actions)
    # print('---------------------')

    self.recent_moves.append(best_action)
    
    if self.isStuck() and len(evaluations) > 1:
      self.stuck_counter = 0
      del evaluations[best_action]
      self.recent_moves.pop()
      best_action = evaluations.argMax()
      self.recent_moves.append(best_action)

      if not agent.isPacman and len(inRange) > 0:
        self.findNewEntryPoint(gameState, agentLocation)
        self.debugDraw([agentLocation],[1,0,0])


    # print('haiya '+str(agentLocation))
    # print(agent.numCarrying - carrying)

    if (agent.numCarrying - carrying) == 0 and agent.isPacman:
      self.inactivity += 1
    elif agent.numCarrying > 0:
      self.inactivity = 0

    return best_action

class ProtectingAgent(ReflexCaptureAgent):
  """
  A reflex agent that keeps its side Pacman-free. Again,
  this is to give you an idea of what a defensive agent
  could be like.  It is not the best or only way to make
  such an agent.
  """
  # def __init__(self, index):
  #   CaptureAgent.__init__(self, index)
  #   self.lastFoodEaten = None
  #   self.lastFood = []
  #   self.currentFoodList = []
  #   self.destination = None
  #   self.nonZeroCount = 0
  lastFoodEaten = None
  lastFood = []
  currentFoodList = []
  destination = None
  nonZeroCount = 0

  def registerInitialState(self, gameState):
    CaptureAgent.registerInitialState(self, gameState)
    self.findDefensePosition(gameState)
    self.lastFoodEaten = None
    self.lastFood = []
    self.currentFoodList = []
    self.destination = None
    self.nonZeroCount = 0
    
  #finding all the open positions and setting the mid position as the defense area
  def findDefensePosition(self,gameState):
    self.defensePositions = []
    width = gameState.data.layout.width
    height = gameState.data.layout.height
    middleX = int((width-2)/2)
    if not self.red:
      middleX +=1
    middleY = int((height-2)/2)
    for i in range(1,height-1):
      if not gameState.hasWall(middleX,i):
        self.defensePositions.append((middleX,i))
    if len(self.defensePositions)<=2:
      self.firstDefensePosition = self.defensePositions[0]
    else:
      self.firstDefensePosition = self.defensePositions[int(len(self.defensePositions)/2)]

  #returns the position of nearst enemy  
  def getClosestEnemyPacman(self,gameState):
    opponents = self.getOpponents(gameState)
    dists = []
    opponentPos = []
    closestEnemies = []
    closestEnemy = None
    
    pacmen = []
    minDis =99999999
    myPos = gameState.getAgentState(self.index).getPosition()
    for index in self.getOpponents(gameState):
      opponent = gameState.getAgentState(index)
      if  opponent.isPacman  and opponent.getPosition() != None:                
          pacmen.append(opponent.getPosition())
    #when enemy is nearby
    if len(pacmen)>0:
      for pos in pacmen:
        dis = self.getMazeDistance(myPos,pos)
        if dis <minDis:
          minDis = dis
          closestEnemies.append(pos)
      closestEnemy = closestEnemies[-1]


    else:
      #when enemy's position is not known, use the position of food eaten
      if len(self.lastFood)>0 and len(self.currentFoodList)<len(self.lastFood):
        foodEaten = set(self.lastFood) - set(self.currentFoodList)
        closestEnemy = foodEaten.pop()
    return closestEnemy

    

  def chooseAction(self,gameState):
    self.currentFoodList = self.getFoodYouAreDefending(gameState).asList()
    self.myPos = gameState.getAgentPosition(self.index)
    #if reached target, set target as none
    if self.myPos == self.destination:
      self.destination = None
    #gets closest enemy
    closestEnemy = self.getClosestEnemyPacman(gameState)
   #go to closest enemy position
    if closestEnemy!=None:
      self.destination = closestEnemy
     #if closest enemy position is none and there are only few food left, go near food/capsule left
    if self.destination==None:
      if len(self.currentFoodList)< 4:
        self.destination = random.choice(self.currentFoodList + self.getCapsulesYouAreDefending(gameState))
      else:
        self.destination = self.firstDefensePosition


    #dont become pacman and dont reverse if possible
    goodActions = []
    actions = gameState.getLegalActions(self.index)
    actions.remove(Directions.STOP)
    back = Directions.REVERSE[gameState.getAgentState(self.index).configuration.direction]
    if back in actions :
      actions.remove(back)

    for action in actions:
      nextState = gameState.generateSuccessor(self.index,action)
      if not nextState.getAgentState(self.index).isPacman:
        goodActions.append(action)
    
    if len(goodActions)==0:
      self.nonZeroCount = 0
    else:
      self.nonZeroCount +=1
    # if there is no option but to go back, use reverse
    if self.nonZeroCount==0 or self.nonZeroCount>4:
      goodActions.append(back)


    #going to destination using maze distance
    dists = []
    for action in goodActions:
      nextState = gameState.generateSuccessor(self.index,action)
      nextPos = nextState.getAgentPosition(self.index)
      if not nextState.getAgentState(self.index).isPacman:
        dists.append(self.getMazeDistance(nextPos,self.destination))
    minDist = min(dists)
    bestActions = []
    for action,dist in zip(goodActions,dists):
      if minDist == dist:
        bestActions.append(action)
    self.lastFood = self.currentFoodList
    return random.choice(bestActions)
