# Team Information

**Course:** AI Planning for Autonomy (COMP90054_2020_SM2)

**Semester:** Semester 2, 2020

**Instructor:** Nir Lipovetzky, Adrian Pearce

**Team name:** pac-pac-pac

**Team members:**

* 1154197 - Ankita Dhar - addh@student.unimelb.edu.au - ankitadhar
* 813212 - Zexi Liu - zexil1@student.unimelb.edu.au - xIa066
* 1042537 - Hissah Alotaibi - alotaibih@student.unimelb.edu.au - Hissah-Aalotaibi

Replace the lines above with the correct details of members. Delete or add lines as needed.

Student numbers should just be the **numbers**.