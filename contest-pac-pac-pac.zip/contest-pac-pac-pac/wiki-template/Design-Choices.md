# Design Choices

summary of your design choices


## General Comments

_General comments about the project goes here_

## Comments per topic

## Offense

## Defense
