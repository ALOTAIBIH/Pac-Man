# ys.py: extended from baselineTeam.py
# ---------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).

# ---------------
# Licensing Information: Please do not distribute or publish solutions to this
# project. You are free to use and extend these projects for educational
# purposes. The Pacman AI projects were developed at UC Berkeley, primarily by
# John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# For more info, see http://inst.eecs.berkeley.edu/~cs188/sp09/pacman.html

from captureAgents import CaptureAgent
import random, time, util, sys
from game import Directions
from util import manhattanDistance as mdist
from util import nearestPoint, Counter
import game

SIGHT_RANGE = 5
NOISE = 6


def createTeam(firstIndex, secondIndex, isRed,
  first = 'OffensiveReflexAgent', second = 'DefensiveReflexAgent'):
  agents = [eval(first)(firstIndex), eval(second)(secondIndex)]
  share = SharedInfo(isRed, agents)
  return agents


class SharedInfo():

  def __init__(self, isRed, agents):
    self.isRed = isRed
    self.agents = agents
    for agent in self.agents:
      agent.registerSharedInfo(self)
    self.ownIndexes = [agent.index for agent in self.agents]
    self.attack = True
    self.initialised = False    
    self.first_move = 0 in self.ownIndexes
    

  def initialise(self, gameState):
    self.initialised = True

    halfGrid = gameState.getRedFood()
    self.width = halfGrid.width
    self.height = halfGrid.height
    self.walls = gameState.getWalls()

    self.oppLocs = {}
    for oppIndex in self.agents[0].getOpponents(gameState):
      self.oppLocs[oppIndex] = Counter({gameState.getInitialAgentPosition(oppIndex): 1})

    self.numAgents = gameState.getNumAgents()


  def updateOppLocations(self, gameState, agentIndex):
    moved = (agentIndex + self.numAgents - 1) % self.numAgents

    agentDists = gameState.getAgentDistances()

    locDict = {index: gameState.getAgentPosition(index) for index in range(self.numAgents)}
    currLoc = locDict[agentIndex]
    ownLocs = [locDict[agent.index] for agent in self.agents]
    
    for oppIndex, oldLocs in self.oppLocs.items():
      pos = gameState.getAgentPosition(oppIndex)
      # if the pacman just died, if a food just disappeared
      if pos is not None:
        self.oppLocs[oppIndex] = Counter({pos: 1})
        continue

      newLocs = Counter()
      for x, y in oldLocs:
        cands = [(x, y)]
        if oppIndex == moved:
          for u, v in [(x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)]:
            if not self.walls[u][v]:
              cands.append((u, v))
        oldprob = self.oppLocs[oppIndex][(x,y)]
        prob = oldprob / len(cands)
        for loc in cands:
          newLocs[loc] += prob

      total = 0
      for loc, prob in newLocs.items():
        if self.isLocPossible(loc, ownLocs, currLoc, agentDists[oppIndex]):
          total += prob
        else:
          newLocs[loc] = 0

      self.oppLocs[oppIndex] = Counter()
      if total == 0: # temporary
        continue
      for loc, prob in newLocs.items():
        if prob != 0:
          self.oppLocs[oppIndex][loc] = prob / total
    # print(self.oppLocs)


  def isLocPossible(self, loc, ownLocs, currLoc, ndist):
    x, y = loc
    return (all(mdist(loc, ownLoc) > SIGHT_RANGE for ownLoc in ownLocs)
            and abs(ndist - mdist(currLoc, loc)) <= NOISE)


class ReflexCaptureAgent(CaptureAgent):
  """
  A base class for reflex agents that chooses score-maximizing actions
  """
  def registerSharedInfo(self, share): # this is new!
    self.share = share
 
  def registerInitialState(self, gameState):
    self.start = gameState.getAgentPosition(self.index)
    CaptureAgent.registerInitialState(self, gameState)

    if not self.share.initialised: # this is new!
      self.share.initialise(gameState)

  def chooseAction(self, gameState):
    """
    Picks among the actions with the highest Q(s,a).
    """

    # this is new!
    self.share.updateOppLocations(gameState, self.index)
    self.displayDistributionsOverPositions([dist.copy() for dist in self.share.oppLocs.values() if dist])

    actions = gameState.getLegalActions(self.index)

    # You can profile your evaluation time by uncommenting these lines
    # start = time.time()
    values = [self.evaluate(gameState, a) for a in actions]
    # print 'eval time for agent %d: %.4f' % (self.index, time.time() - start)

    maxValue = max(values)
    bestActions = [a for a, v in zip(actions, values) if v == maxValue]

    foodLeft = len(self.getFood(gameState).asList())

    if foodLeft <= 2:
      bestDist = 9999
      for action in actions:
        successor = self.getSuccessor(gameState, action)
        pos2 = successor.getAgentPosition(self.index)
        dist = self.getMazeDistance(self.start,pos2)
        if dist < bestDist:
          bestAction = action
          bestDist = dist
      return bestAction

    return random.choice(bestActions)

  def getSuccessor(self, gameState, action):
    """
    Finds the next successor which is a grid position (location tuple).
    """
    successor = gameState.generateSuccessor(self.index, action)
    pos = successor.getAgentState(self.index).getPosition()
    if pos != nearestPoint(pos):
      # Only half a grid position was covered
      return successor.generateSuccessor(self.index, action)
    else:
      return successor

  def evaluate(self, gameState, action):
    """
    Computes a linear combination of features and feature weights
    """
    features = self.getFeatures(gameState, action)
    weights = self.getWeights(gameState, action)
    return features * weights

  def getFeatures(self, gameState, action):
    """
    Returns a counter of features for the state
    """
    features = util.Counter()
    successor = self.getSuccessor(gameState, action)
    features['successorScore'] = self.getScore(successor)
    return features

  def getWeights(self, gameState, action):
    """
    Normally, weights do not depend on the gamestate.  They can be either
    a counter or a dictionary.
    """
    return {'successorScore': 1.0}

class OffensiveReflexAgent(ReflexCaptureAgent):
  """
  A reflex agent that seeks food. This is an agent
  we give you to get an idea of what an offensive agent might look like,
  but it is by no means the best or only way to build an offensive agent.
  """
  def getFeatures(self, gameState, action):
    features = util.Counter()
    successor = self.getSuccessor(gameState, action)
    foodList = self.getFood(successor).asList()    
    features['successorScore'] = -len(foodList)#self.getScore(successor)

    # Compute distance to the nearest food

    if len(foodList) > 0: # This should always be True,  but better safe than sorry
      myPos = successor.getAgentState(self.index).getPosition()
      minDistance = min([self.getMazeDistance(myPos, food) for food in foodList])
      features['distanceToFood'] = minDistance
    return features

  def getWeights(self, gameState, action):
    return {'successorScore': 100, 'distanceToFood': -1}

class DefensiveReflexAgent(ReflexCaptureAgent):
  """
  A reflex agent that keeps its side Pacman-free. Again,
  this is to give you an idea of what a defensive agent
  could be like.  It is not the best or only way to make
  such an agent.
  """

  def getFeatures(self, gameState, action):
    features = util.Counter()
    successor = self.getSuccessor(gameState, action)

    myState = successor.getAgentState(self.index)
    myPos = myState.getPosition()

    # Computes whether we're on defense (1) or offense (0)
    features['onDefense'] = 1
    if myState.isPacman: features['onDefense'] = 0

    # Computes distance to invaders we can see
    enemies = [successor.getAgentState(i) for i in self.getOpponents(successor)]
    invaders = [a for a in enemies if a.isPacman and a.getPosition() != None]
    features['numInvaders'] = len(invaders)
    if len(invaders) > 0:
      dists = [self.getMazeDistance(myPos, a.getPosition()) for a in invaders]
      features['invaderDistance'] = min(dists)

    if action == Directions.STOP: features['stop'] = 1
    rev = Directions.REVERSE[gameState.getAgentState(self.index).configuration.direction]
    if action == rev: features['reverse'] = 1

    return features

  def getWeights(self, gameState, action):
    return {'numInvaders': -1000, 'onDefense': 100, 'invaderDistance': -10, 'stop': -100, 'reverse': -2}
